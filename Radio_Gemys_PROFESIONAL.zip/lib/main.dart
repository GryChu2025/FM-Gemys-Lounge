import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:share_plus/share_plus.dart';

void main() {
  runApp(const RadioApp());
}

class RadioApp extends StatelessWidget {
  const RadioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Radio Gemys Pro',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF0A2A66),
      ),
      home: const RadioHome(),
    );
  }
}

class RadioHome extends StatefulWidget {
  const RadioHome({super.key});

  @override
  State<RadioHome> createState() => _RadioHomeState();
}

class _RadioHomeState extends State<RadioHome> {
  final player = AudioPlayer();
  bool playing = false;

  final String url = "http://45.182.223.219:8000/stream";

  Future<void> toggle() async {
    if (playing) {
      await player.pause();
    } else {
      await player.setUrl(url);
      await player.play();
    }
    setState(() {
      playing = !playing;
    });
  }

  void shareApp() {
    Share.share("Escuchá Radio Gemys Pro: $url");
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            const Icon(Icons.radio, size: 120, color: Colors.white),

            const SizedBox(height: 20),

            Text(
              "Radio Gemys Pro",
              style: const TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 40),

            GestureDetector(
              onTap: toggle,
              child: Container(
                width: 120,
                height: 120,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: playing ? Colors.red : Colors.green,
                ),
                child: Icon(
                  playing ? Icons.pause : Icons.play_arrow,
                  size: 60,
                  color: Colors.white,
                ),
              ),
            ),

            const SizedBox(height: 30),

            ElevatedButton.icon(
              onPressed: shareApp,
              icon: const Icon(Icons.share),
              label: const Text("Compartir"),
            ),

          ],
        ),
      ),
    );
  }
}